﻿namespace ProjetoLittlesDelivery
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.btnEstoque = new System.Windows.Forms.Button();
            this.btnCliente = new System.Windows.Forms.Button();
            this.btnEndereco = new System.Windows.Forms.Button();
            this.btnItensProdutos = new System.Windows.Forms.Button();
            this.btnItensVendidos = new System.Windows.Forms.Button();
            this.btnProdutos = new System.Windows.Forms.Button();
            this.btnVenda = new System.Windows.Forms.Button();
            this.btnTelefone = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.labelCopyright = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtFaturamento = new System.Windows.Forms.TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.labelFaturamento = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnEstoque
            // 
            this.btnEstoque.BackColor = System.Drawing.Color.DarkSalmon;
            this.btnEstoque.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEstoque.Location = new System.Drawing.Point(125, 189);
            this.btnEstoque.Name = "btnEstoque";
            this.btnEstoque.Size = new System.Drawing.Size(104, 70);
            this.btnEstoque.TabIndex = 0;
            this.btnEstoque.Text = "Estoque";
            this.btnEstoque.UseVisualStyleBackColor = false;
            // 
            // btnCliente
            // 
            this.btnCliente.BackColor = System.Drawing.Color.DarkSalmon;
            this.btnCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCliente.Location = new System.Drawing.Point(12, 37);
            this.btnCliente.Name = "btnCliente";
            this.btnCliente.Size = new System.Drawing.Size(104, 70);
            this.btnCliente.TabIndex = 0;
            this.btnCliente.Text = "Cliente";
            this.btnCliente.UseVisualStyleBackColor = false;
            // 
            // btnEndereco
            // 
            this.btnEndereco.BackColor = System.Drawing.Color.DarkSalmon;
            this.btnEndereco.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEndereco.Location = new System.Drawing.Point(12, 113);
            this.btnEndereco.Name = "btnEndereco";
            this.btnEndereco.Size = new System.Drawing.Size(104, 70);
            this.btnEndereco.TabIndex = 0;
            this.btnEndereco.Text = "Endereco";
            this.btnEndereco.UseVisualStyleBackColor = false;
            // 
            // btnItensProdutos
            // 
            this.btnItensProdutos.BackColor = System.Drawing.Color.DarkSalmon;
            this.btnItensProdutos.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnItensProdutos.Location = new System.Drawing.Point(125, 265);
            this.btnItensProdutos.Name = "btnItensProdutos";
            this.btnItensProdutos.Size = new System.Drawing.Size(104, 70);
            this.btnItensProdutos.TabIndex = 0;
            this.btnItensProdutos.Text = "Itens Produtos";
            this.btnItensProdutos.UseVisualStyleBackColor = false;
            // 
            // btnItensVendidos
            // 
            this.btnItensVendidos.BackColor = System.Drawing.Color.DarkSalmon;
            this.btnItensVendidos.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnItensVendidos.Location = new System.Drawing.Point(12, 265);
            this.btnItensVendidos.Name = "btnItensVendidos";
            this.btnItensVendidos.Size = new System.Drawing.Size(104, 70);
            this.btnItensVendidos.TabIndex = 0;
            this.btnItensVendidos.Text = "Itens Vendidos";
            this.btnItensVendidos.UseVisualStyleBackColor = false;
            // 
            // btnProdutos
            // 
            this.btnProdutos.BackColor = System.Drawing.Color.DarkSalmon;
            this.btnProdutos.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProdutos.Location = new System.Drawing.Point(12, 189);
            this.btnProdutos.Name = "btnProdutos";
            this.btnProdutos.Size = new System.Drawing.Size(104, 70);
            this.btnProdutos.TabIndex = 0;
            this.btnProdutos.Text = "Produtos";
            this.btnProdutos.UseVisualStyleBackColor = false;
            // 
            // btnVenda
            // 
            this.btnVenda.BackColor = System.Drawing.Color.DarkSalmon;
            this.btnVenda.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVenda.Location = new System.Drawing.Point(125, 113);
            this.btnVenda.Name = "btnVenda";
            this.btnVenda.Size = new System.Drawing.Size(104, 70);
            this.btnVenda.TabIndex = 0;
            this.btnVenda.Text = "Venda";
            this.btnVenda.UseVisualStyleBackColor = false;
            // 
            // btnTelefone
            // 
            this.btnTelefone.BackColor = System.Drawing.Color.DarkSalmon;
            this.btnTelefone.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTelefone.Location = new System.Drawing.Point(125, 37);
            this.btnTelefone.Name = "btnTelefone";
            this.btnTelefone.Size = new System.Drawing.Size(104, 70);
            this.btnTelefone.TabIndex = 1;
            this.btnTelefone.Text = "Telefone";
            this.btnTelefone.UseVisualStyleBackColor = false;
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.Location = new System.Drawing.Point(776, 529);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(28, 28);
            this.panel1.TabIndex = 2;
            // 
            // labelCopyright
            // 
            this.labelCopyright.AutoSize = true;
            this.labelCopyright.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCopyright.Location = new System.Drawing.Point(810, 541);
            this.labelCopyright.Name = "labelCopyright";
            this.labelCopyright.Size = new System.Drawing.Size(72, 16);
            this.labelCopyright.TabIndex = 3;
            this.labelCopyright.Text = "V1.0 beta";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 400);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(846, 66);
            this.label1.TabIndex = 4;
            this.label1.Text = "Esse software te auxiliará no seu controle de estoque, dados de vendas e cadastro" +
    "\r\ndos seus clientes.";
            // 
            // txtFaturamento
            // 
            this.txtFaturamento.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFaturamento.Location = new System.Drawing.Point(513, 47);
            this.txtFaturamento.Name = "txtFaturamento";
            this.txtFaturamento.Size = new System.Drawing.Size(145, 34);
            this.txtFaturamento.TabIndex = 5;
            this.txtFaturamento.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(307, 100);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(287, 22);
            this.dateTimePicker1.TabIndex = 6;
            // 
            // labelFaturamento
            // 
            this.labelFaturamento.AutoSize = true;
            this.labelFaturamento.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFaturamento.Location = new System.Drawing.Point(303, 59);
            this.labelFaturamento.Name = "labelFaturamento";
            this.labelFaturamento.Size = new System.Drawing.Size(204, 22);
            this.labelFaturamento.TabIndex = 7;
            this.labelFaturamento.Text = "Faturamento total diário:";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(885, 566);
            this.Controls.Add(this.labelFaturamento);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.txtFaturamento);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.labelCopyright);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnTelefone);
            this.Controls.Add(this.btnVenda);
            this.Controls.Add(this.btnProdutos);
            this.Controls.Add(this.btnItensVendidos);
            this.Controls.Add(this.btnItensProdutos);
            this.Controls.Add(this.btnEndereco);
            this.Controls.Add(this.btnCliente);
            this.Controls.Add(this.btnEstoque);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Menu";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnEstoque;
        private System.Windows.Forms.Button btnCliente;
        private System.Windows.Forms.Button btnEndereco;
        private System.Windows.Forms.Button btnItensProdutos;
        private System.Windows.Forms.Button btnItensVendidos;
        private System.Windows.Forms.Button btnProdutos;
        private System.Windows.Forms.Button btnVenda;
        private System.Windows.Forms.Button btnTelefone;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label labelCopyright;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtFaturamento;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label labelFaturamento;
    }
}